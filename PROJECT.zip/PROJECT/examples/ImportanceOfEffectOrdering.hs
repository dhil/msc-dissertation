{-# LANGUAGE FlexibleContexts #-}

-- Importance of effect ordering
-- Example reproduced from http://book.realworldhaskell.org/read/monad-transformers.html

import Control.Monad.Trans.Maybe
import Control.Monad.Writer


type A = WriterT String Maybe
type B = MaybeT (Writer String)

a :: A ()
a = problem

b :: B ()
b = problem

problem :: MonadWriter String m => m ()
problem = do
  tell "this is where I fail"
  fail "oops"

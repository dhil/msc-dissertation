-- Coffee dispenser model using Monad Transformers
import Control.Monad.Trans.Reader
import Control.Monad.Trans.Writer
import Control.Monad.Trans
import Control.Monad.Random

data Consumable = Coffee | Tea
                  deriving Show

type ItemCode  = Integer
type Inventory = [(ItemCode,Consumable)]

inventory = [(1,Coffee),(2,Tea)]

dispenser1 :: ItemCode -> ReaderT Inventory Maybe Consumable
dispenser1 n = do inv <- ask
                  item <- lift $ lookup n inv
                  return item

dispense1 :: ItemCode -> IO ()
dispense1 n = display . runReaderWithInv $ dispenser1 n

dispenser2 :: ItemCode -> WriterT String (ReaderT Inventory Maybe) Consumable
dispenser2 n = do inv <- lift ask
                  item <- lift . lift $ lookup n inv
                  tell $ "Dispensing " ++ show item ++ "..."
                  return item

dispense2 :: ItemCode -> IO ()
dispense2 n = display . runReaderWithInv . execWriterT $ dispenser2 n

dispenser3 :: ItemCode -> RandT StdGen (WriterT String (ReaderT Inventory Maybe)) Consumable
dispenser3 n = do val <- getRandomR (1,20)
                  inv <- lift . lift $ ask
                  item <- lift . lift . lift $ lookup' val n inv
                  lift . tell $ "Dispensing " ++ show item ++ "..."
                  return item
                    where
                      lookup' :: Int -> ItemCode -> Inventory -> Maybe Consumable
                      lookup' v n inv = if v > 10 then lookup n inv else Nothing

dispense3 :: ItemCode -> IO ()
dispense3 n =
  do r <- newStdGen
     display . runReaderWithInv . execWriterT . (flip evalRandT r) $ dispenser3 n


display :: Show a => a -> IO ()
display = putStrLn . show

runReaderWithInv :: ReaderT Inventory m a -> m a
runReaderWithInv = flip runReaderT inventory

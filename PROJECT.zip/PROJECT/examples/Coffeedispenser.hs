-- Coffee dispenser model
import Control.Monad

data Consumable = Coffee | Tea
                  deriving Show

type ItemCode  = Integer
type Inventory = [(ItemCode,Consumable)]

inventory = [(1,Coffee),(2,Tea)]

data Reader e a = Reader (e -> a)

instance Functor (Reader e) where
  fmap f (Reader x) = Reader $ \e -> (f . x) e

instance Applicative (Reader e) where
  pure x          = Reader $ \e -> x
  (Reader f) <*> (Reader x) = Reader $ \e -> (f e) (x e)

instance Monad (Reader e) where
  return x = Reader $ \e -> x
  x >>= f  = Reader $ \e -> runReader (f (runReader x e)) e

runReader :: Reader e a -> e -> a
runReader (Reader f) e = f e

ask :: Reader a a
ask = Reader $ \e -> e

dispenser :: ItemCode -> Reader Inventory (Maybe Consumable)
dispenser n = do env <- ask
                 let item = lookup n env
                 return item

dispense :: ItemCode -> IO ()
dispense n = putStrLn . show . (flip runReader inventory) $ dispenser n

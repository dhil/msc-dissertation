type token =
  | LBRACE
  | RBRACE
  | LBRACKET
  | RBRACKET
  | LPAREN
  | RPAREN
  | COLON
  | COMMA
  | UNDERSCORE
  | TRUE
  | FALSE
  | NULL
  | CLOSURETABLE
  | SERVERFUNC
  | STRING of (string)
  | INT of (Num.num)
  | FLOAT of (float)

open Parsing;;
let _ = parse_error;;
# 2 "jsonparse.mly"
open Utility

(* let unparse_label = function *)
(*   | `Char c -> String.make 1 c *)
(*   | `List (`Char _::_) as s -> Value.unbox_string s *)
(*   | r -> (failwith "(json) error decoding label " ^ Show.show Value.show_t r) *)

(* BUG: need to unescape strings
   (where they are escaped in json.ml)
*)

# 35 "jsonparse.ml"
let yytransl_const = [|
  257 (* LBRACE *);
  258 (* RBRACE *);
  259 (* LBRACKET *);
  260 (* RBRACKET *);
  261 (* LPAREN *);
  262 (* RPAREN *);
  263 (* COLON *);
  264 (* COMMA *);
  265 (* UNDERSCORE *);
  266 (* TRUE *);
  267 (* FALSE *);
  268 (* NULL *);
  269 (* CLOSURETABLE *);
  270 (* SERVERFUNC *);
    0|]

let yytransl_block = [|
  271 (* STRING *);
  272 (* INT *);
  273 (* FLOAT *);
    0|]

let yylhs = "\255\255\
\001\000\003\000\003\000\004\000\004\000\006\000\006\000\007\000\
\007\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\008\000\008\000\008\000\009\000\005\000\010\000\010\000\
\000\000"

let yylen = "\002\000\
\001\000\002\000\003\000\003\000\005\000\002\000\003\000\001\000\
\003\000\001\000\001\000\001\000\001\000\001\000\001\000\001\000\
\001\000\004\000\007\000\008\000\001\000\001\000\001\000\001\000\
\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\015\000\016\000\017\000\000\000\
\000\000\021\000\024\000\023\000\025\000\001\000\013\000\014\000\
\010\000\011\000\012\000\002\000\022\000\000\000\000\000\006\000\
\008\000\000\000\000\000\000\000\003\000\000\000\000\000\007\000\
\000\000\000\000\000\000\000\000\004\000\009\000\018\000\000\000\
\000\000\000\000\005\000\000\000\019\000\000\000\020\000"

let yydgoto = "\002\000\
\013\000\014\000\015\000\022\000\023\000\016\000\026\000\017\000\
\018\000\019\000"

let yysindex = "\001\000\
\029\255\000\000\003\255\000\255\000\000\000\000\000\000\005\255\
\006\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\018\255\016\255\000\000\
\000\000\017\255\247\254\015\255\000\000\019\255\029\255\000\000\
\029\255\027\255\022\255\026\255\000\000\000\000\000\000\031\255\
\029\255\035\255\000\000\004\255\000\000\020\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\252\255\000\000\003\000\018\000\000\000\000\000\000\000\
\000\000\000\000"

let yytablesize = 48
let yytable = "\025\000\
\003\000\001\000\004\000\024\000\020\000\045\000\034\000\027\000\
\028\000\005\000\006\000\007\000\008\000\009\000\010\000\011\000\
\012\000\021\000\021\000\029\000\032\000\047\000\031\000\035\000\
\033\000\030\000\037\000\030\000\038\000\003\000\039\000\004\000\
\041\000\021\000\042\000\044\000\043\000\040\000\005\000\006\000\
\007\000\008\000\009\000\010\000\011\000\012\000\046\000\036\000"

let yycheck = "\004\000\
\001\001\001\000\003\001\004\001\002\001\002\001\016\001\003\001\
\003\001\010\001\011\001\012\001\013\001\014\001\015\001\016\001\
\017\001\015\001\015\001\002\001\004\001\002\001\007\001\009\001\
\008\001\008\001\031\000\008\001\033\000\001\001\004\001\003\001\
\007\001\015\001\004\001\001\001\041\000\016\001\010\001\011\001\
\012\001\013\001\014\001\015\001\016\001\017\001\044\000\030\000"

let yynames_const = "\
  LBRACE\000\
  RBRACE\000\
  LBRACKET\000\
  RBRACKET\000\
  LPAREN\000\
  RPAREN\000\
  COLON\000\
  COMMA\000\
  UNDERSCORE\000\
  TRUE\000\
  FALSE\000\
  NULL\000\
  CLOSURETABLE\000\
  SERVERFUNC\000\
  "

let yynames_block = "\
  STRING\000\
  INT\000\
  FLOAT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 28 "jsonparse.mly"
        ( _1 )
# 150 "jsonparse.ml"
               : Value.t))
; (fun __caml_parser_env ->
    Obj.repr(
# 31 "jsonparse.mly"
                        ( `Record [] )
# 156 "jsonparse.ml"
               : 'object_))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'members) in
    Obj.repr(
# 32 "jsonparse.mly"
                        ( match _2 with 
                            | ["_c", c] -> Value.box_char ((Value.unbox_string c).[0])
                            | ["_label", l; "_value", v]
                            | ["_value", v; "_label", l] -> `Variant (Value.unbox_string l, v)
                            | ["_db", db] ->
                                begin
                                  match db with
                                    | `Record bs ->
                                        let driver = Value.unbox_string (List.assoc "driver" bs)
                                        and params =
                                          Value.reconstruct_db_string
                                            (Value.unbox_string (List.assoc "name" bs),
                                             Value.unbox_string (List.assoc "args" bs)) in
                                          `Database (Value.db_connect driver params) 
                                    | _ -> failwith ("jsonparse: database value must be a record")
                                end
                            | ["_table", t] ->
                                begin
                                  match t with
                                    | `Record bs ->
                                        let db =
                                          begin
                                            match List.assoc "db" bs with
                                              | `Database db -> db
                                              | _ -> failwith ("jsonparse: first argument to a table must be a database")
                                          end
                                        and name = Value.unbox_string (List.assoc "name" bs)
                                        and row =
                                          begin
                                            match DesugarDatatypes.read ~aliases:Env.String.empty (Value.unbox_string (List.assoc "row" bs)) with
                                                | `Record row -> row
                                                | _ -> failwith ("jsonparse: tables must have record type")
                                          end
                                        in
                                          `Table (db, name, row)
                                    | _ -> failwith ("jsonparse: table value must be a record")
                                end
                            | ["_xml", t] ->
                                  begin
                                    match t with
                                      | `List [node_type; s] when (Value.unbox_string node_type = "TEXT") ->
                                          `XML (Value.Text (Value.unbox_string s))
                                      | `List [node_type; tag; attrs; body]
                                          when (Value.unbox_string node_type = "ELEMENT") ->
                                          let tag = Value.unbox_string tag in
                                          let attrs =
                                            match attrs with
                                              | `Record attrs -> attrs
                                              | _ -> failwith ("jsonparse: xml attributes should be an attribute record") in
                                            let attrs =
                                              List.fold_left
                                                (fun attrs (label, value) ->
                                                   Value.Attr (label, Value.unbox_string value) :: attrs)
                                                [] attrs in
                                              let body =
                                                match body with
                                                  | `List body -> List.map
                                                      (function 
                                                         | `XML body -> body
                                                         | _ -> failwith ("jsonparse: xml body should be a list of xmlitems"))
                                                        body
                                                  | _ -> failwith ("jsonparse: xml body should be a list of xmlitems")
                                              in
                                                `XML (Value.Node (tag, attrs @ body))
                                      | _ ->
                                          failwith ("jsonparse: xml should be either a text node or an element node. Got: "
                                                    ^ Value.string_of_value t)
                                  end
                            | _ -> `Record (List.rev _2)
                        )
# 232 "jsonparse.ml"
               : 'object_))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'id) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 104 "jsonparse.mly"
                                     ( [_1, _3] )
# 240 "jsonparse.ml"
               : 'members))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'members) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'id) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 105 "jsonparse.mly"
                                     ( (_3, _5) :: _1 )
# 249 "jsonparse.ml"
               : 'members))
; (fun __caml_parser_env ->
    Obj.repr(
# 108 "jsonparse.mly"
                                     ( `List ([]) )
# 255 "jsonparse.ml"
               : 'array))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'elements) in
    Obj.repr(
# 109 "jsonparse.mly"
                                     ( `List (List.rev _2) )
# 262 "jsonparse.ml"
               : 'array))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 112 "jsonparse.mly"
                                     ( [_1] )
# 269 "jsonparse.ml"
               : 'elements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'elements) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 113 "jsonparse.mly"
                                     ( _3 :: _1 )
# 277 "jsonparse.ml"
               : 'elements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'func) in
    Obj.repr(
# 116 "jsonparse.mly"
                                     ( _1 )
# 284 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'string) in
    Obj.repr(
# 117 "jsonparse.mly"
                                     ( _1 )
# 291 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'number) in
    Obj.repr(
# 118 "jsonparse.mly"
                                     ( _1 )
# 298 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'object_) in
    Obj.repr(
# 119 "jsonparse.mly"
                                     ( _1 )
# 305 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'array) in
    Obj.repr(
# 120 "jsonparse.mly"
                                     ( _1 )
# 312 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    Obj.repr(
# 121 "jsonparse.mly"
                                     ( `Bool true )
# 318 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    Obj.repr(
# 122 "jsonparse.mly"
                                     ( `Bool false )
# 324 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    Obj.repr(
# 123 "jsonparse.mly"
                                     ( `Record [] (* Or an error? *) )
# 330 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 1 : Num.num) in
    Obj.repr(
# 126 "jsonparse.mly"
                                     ( `ClientFunction("_closureTable["^
                                                       Num.string_of_num _3^"]")
                                     )
# 339 "jsonparse.ml"
               : 'func))
; (fun __caml_parser_env ->
    let _4 = (Parsing.peek_val __caml_parser_env 3 : Num.num) in
    Obj.repr(
# 130 "jsonparse.mly"
                                     ( (* The underscore here is a nuisance; would be good to remove it. *)
                                       `FunctionPtr(Num.int_of_num _4,
                                                    Value.empty_env (Utility.IntMap.empty)) )
# 348 "jsonparse.ml"
               : 'func))
; (fun __caml_parser_env ->
    let _4 = (Parsing.peek_val __caml_parser_env 4 : Num.num) in
    let _7 = (Parsing.peek_val __caml_parser_env 1 : 'members) in
    Obj.repr(
# 134 "jsonparse.mly"
                                     ( `FunctionPtr(Num.int_of_num _4,
                                                    Value.extend (Value.empty_env Utility.IntMap.empty) 
                                                      (Utility.IntMap.from_alist
                                                        (List.map (fun (x,y) ->
                                                            (int_of_string x,
                                                                (y,`Local))) _7))) )
# 361 "jsonparse.ml"
               : 'func))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 142 "jsonparse.mly"
                                     ( Value.box_string _1 )
# 368 "jsonparse.ml"
               : 'string))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 144 "jsonparse.mly"
                                     ( _1 )
# 375 "jsonparse.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : float) in
    Obj.repr(
# 147 "jsonparse.mly"
                                    ( `Float _1 )
# 382 "jsonparse.ml"
               : 'number))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Num.num) in
    Obj.repr(
# 148 "jsonparse.mly"
                                    ( `Int _1 )
# 389 "jsonparse.ml"
               : 'number))
(* Entry parse_json *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let parse_json (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Value.t)

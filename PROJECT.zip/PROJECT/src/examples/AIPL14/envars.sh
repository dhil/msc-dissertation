#!/bin/bash
export PATH=/home/others/philw/links:$PATH
export LINKS_LIB=/home/others/philw/links
